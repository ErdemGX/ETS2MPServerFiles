ETS2HookingOldSandbox aka ETS2MP
======

If you want to learn something from this code you do it at your own risk, high amounts of memory leaks ahead!

In fact what you can find on this repo is very old code that was meant to be Multiplayer mod for Euro Truck Simulator 2. Most of the assumptions i made in the days of writing this code about functions purpose and variables are wrong.

Memory addresses should be compatible with 1.3.1 update for Euro Truck Simulator 2. (Retail probably)

I provide no support for this code base and you use it on your own risk.

