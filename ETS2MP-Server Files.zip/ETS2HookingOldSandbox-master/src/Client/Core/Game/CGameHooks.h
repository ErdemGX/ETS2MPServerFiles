/**************************************************************
 *
 * Solution    : Euro Truck Simulator 2 Multiplayer
 * Project     : Client Core
 * Licence     : See LICENSE in the top level directory
 * File		   : CGameHooks.h
 * Developers  : RootKiller <rootkiller.programmer@gmail.com>,
 *			     Aliqe		<kiklus95@gmail.com>
 *
 ***************************************************************/
#pragma once

class CGameHooks
{
public: 
	static bool Initialize();
};